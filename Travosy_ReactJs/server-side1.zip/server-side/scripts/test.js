import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'mudita07074@gmail.com',
        pass: 'muddu@074',
    },
});

const mailOptions = {
    from: 'mudita07074@gmail.com',
    to: 'mudita07074@gmail.com',
    subject: 'Test Email',
    text: 'This is a test email sent using Nodemailer.',
};

transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        console.error('Error sending email:', error);
    } else {
        console.log('Email sent:', info.response);
    }
});
